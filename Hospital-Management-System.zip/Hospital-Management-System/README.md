# Hospital Management System

A responsive educational Hospital Management System built with Python Flask, SQLite, Bootstrap 5, JavaScript, and Font Awesome. It demonstrates common hospital administration workflows including patient records, doctor directory, appointment scheduling, and billing.

> **Educational use only.** This project is not designed or reviewed for production hospital operations or real patient data. Do not enter real personal or medical information. A professional security, privacy, legal, and compliance review is required before any real-world deployment.

## Features

- Login with Admin, Doctor, and Receptionist roles
- Password hashing and session-based authentication
- Dashboard counts and recent activity
- Patient registration, profile, search, edit, delete
- Doctor directory, specialization, department, availability
- Appointment booking, status updates, conflict checks
- Bills, partial payments, payment history, printable invoice
- Pagination on patient, doctor, and appointment lists
- CSRF protection through Flask-WTF
- SQLite database initialized automatically

## Technology stack

- Python 3
- Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF
- SQLite
- Bootstrap 5, HTML5, CSS3, JavaScript
- Font Awesome

## Windows installation

1. Install Python 3.10 or newer.
2. Open Command Prompt in this folder.
3. Create and activate a virtual environment:

   ```bat
   python -m venv venv
   venv\Scripts\activate
   ```
4. Install dependencies:

   ```bat
   pip install -r requirements.txt
   ```
5. Copy the environment template and edit `SECRET_KEY`:

   ```bat
   copy .env.example .env
   ```
6. Start the app:

   ```bat
   python app.py
   ```
7. Visit http://127.0.0.1:5000

The database and demo users are created automatically on first start.

## Demo login accounts

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `Admin@123` |
| Doctor | `doctor` | `Doctor@123` |
| Receptionist | `receptionist` | `Reception@123` |

These credentials are for local demonstration only. Change them before sharing a running instance. Do not use these passwords in a deployed system.

## Tests

```bat
pytest -q
```

## Project structure

```text
Hospital-Management-System/
├── app.py
├── config.py
├── requirements.txt
├── models/
├── routes/
├── templates/
├── static/
├── database/
├── tests/
├── .env.example
├── .gitignore
├── README.md
└── LICENSE
```

## Screenshots

Add screenshots of your local application here, for example:

- `screenshots/dashboard.png`
- `screenshots/patients.png`
- `screenshots/appointments.png`

## GitHub publishing

Create an empty repository on GitHub, then run:

```bash
git init
git add .
git commit -m "Initial commit: Hospital Management System"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Hospital-Management-System.git
git push -u origin main
```

## Limitations and next steps

This is a learning project, not a clinical or production system. Before real deployment, it would need comprehensive access-control review, audit logging, secure account provisioning, backups, encryption, stronger input validation, database migration management, concurrency-safe appointment booking, privacy controls, monitoring, and jurisdiction-specific compliance work.
