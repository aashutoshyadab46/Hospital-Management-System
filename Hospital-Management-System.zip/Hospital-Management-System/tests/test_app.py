import pytest
from app import app as flask_app, initialize_database
from models import db
from models.models import User, Patient, Doctor, Department, Appointment
from datetime import date, time

@pytest.fixture()
def client(tmp_path):
    flask_app.config.update(
        TESTING=True,
        WTF_CSRF_ENABLED=False,
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{tmp_path / 'test.db'}",
        SECRET_KEY="test-secret"
    )
    with flask_app.app_context():
        db.drop_all()
        db.create_all()
        dept = Department(name="Testing")
        admin = User(username="admin", email="admin@test.local", role="admin")
        admin.set_password("Admin@123")
        receptionist = User(username="receptionist", email="reception@test.local", role="receptionist")
        receptionist.set_password("Reception@123")
        patient = Patient(patient_code="P-1", name="Test Patient", age=25, gender="Other", phone="123")
        doctor = Doctor(doctor_code="D-1", name="Test Doctor", specialization="General", phone="456", email="doctor@test.local", department=dept)
        db.session.add_all([dept, admin, receptionist, patient, doctor])
        db.session.commit()
    with flask_app.test_client() as client:
        yield client
    with flask_app.app_context():
        db.session.remove()
        db.drop_all()

def login(client, username="admin", password="Admin@123"):
    return client.post("/login", data={"username": username, "password": password}, follow_redirects=True)

def test_login_logout(client):
    response = login(client)
    assert response.status_code == 200
    assert b"Dashboard" in response.data
    assert client.get("/logout", follow_redirects=True).status_code == 200

def test_patient_registration(client):
    login(client, "receptionist", "Reception@123")
    response = client.post("/patients/new", data={
        "patient_code":"P-2","name":"New Patient","age":"30","gender":"Female",
        "phone":"999","email":"","address":"","blood_group":"A+","medical_history":""
    }, follow_redirects=True)
    assert response.status_code == 200
    with flask_app.app_context():
        assert Patient.query.filter_by(patient_code="P-2").first() is not None

def test_appointment_conflict(client):
    login(client, "receptionist", "Reception@123")
    with flask_app.app_context():
        patient = Patient.query.filter_by(patient_code="P-1").first()
        doctor = Doctor.query.filter_by(doctor_code="D-1").first()
        db.session.add(Appointment(patient_id=patient.id, doctor_id=doctor.id,
            appointment_date=date(2030,1,1), appointment_time=time(10,0), status="Approved"))
        db.session.commit()
    response = client.post("/appointments/new", data={
        "patient_id":"1","doctor_id":"1","appointment_date":"2030-01-01",
        "appointment_time":"10:00","reason":"Checkup"
    }, follow_redirects=True)
    assert b"already has an active appointment" in response.data

def test_role_authorization(client):
    login(client, "doctor", "wrong-password")
    response = client.get("/billing/", follow_redirects=False)
    assert response.status_code in (302, 401)
