import os
from pathlib import Path
from flask import Flask, redirect, url_for
from flask_wtf.csrf import CSRFProtect
from models import db, login_manager
from models.models import User, Department
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
login_manager.init_app(app)
csrf = CSRFProtect(app)

@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except (ValueError, TypeError):
        return None

from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.patients import patients_bp
from routes.doctors import doctors_bp
from routes.appointments import appointments_bp
from routes.billing import billing_bp

for blueprint in (auth_bp, dashboard_bp, patients_bp, doctors_bp, appointments_bp, billing_bp):
    app.register_blueprint(blueprint)

@app.route("/")
def index():
    return redirect(url_for("dashboard.index") if app.config.get("TESTING") else url_for("auth.login"))

@app.errorhandler(403)
def forbidden(error):
    return "You do not have permission to access this page.", 403

@app.errorhandler(404)
def not_found(error):
    return "The requested page was not found.", 404

def initialize_database():
    with app.app_context():
        Path("database").mkdir(exist_ok=True)
        db.create_all()
        if not Department.query.first():
            db.session.add_all([
                Department(name="Cardiology"),
                Department(name="Neurology"),
                Department(name="Orthopedics"),
                Department(name="Pediatrics"),
                Department(name="General Medicine"),
            ])
        demo_users = [
            ("admin", "admin@hospital.local", "admin", "Admin@123"),
            ("doctor", "doctor@hospital.local", "doctor", "Doctor@123"),
            ("receptionist", "receptionist@hospital.local", "receptionist", "Reception@123"),
        ]
        for username, email, role, password in demo_users:
            if not User.query.filter_by(username=username).first():
                user = User(username=username, email=email, role=role)
                user.set_password(password)
                db.session.add(user)
        db.session.commit()

if __name__ == "__main__":
    initialize_database()
    app.run(debug=os.getenv("FLASK_DEBUG", "0") == "1")
