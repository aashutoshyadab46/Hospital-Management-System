from datetime import datetime, date, time
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from models import db
from models.models import Appointment, Patient, Doctor
from routes.common import roles_required

appointments_bp = Blueprint("appointments", __name__, url_prefix="/appointments")
ACTIVE_STATUSES = ("Pending", "Approved")

@appointments_bp.route("/")
@login_required
def index():
    query = Appointment.query
    if current_user.role == "doctor":
        # Doctor accounts can view appointments only when linked through a matching
        # doctor email. This educational app does not include a separate user-doctor mapping.
        doctor = Doctor.query.filter_by(email=current_user.email).first()
        query = query.filter_by(doctor_id=doctor.id) if doctor else query.filter_by(id=-1)
    status = request.args.get("status", "")
    if status:
        query = query.filter_by(status=status)
    pagination = query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc()).paginate(
        page=request.args.get("page", 1, type=int), per_page=10, error_out=False
    )
    return render_template("appointments/index.html", pagination=pagination, status=status)

@appointments_bp.route("/new", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def create():
    patients = Patient.query.order_by(Patient.name).all()
    doctors = Doctor.query.filter_by(available=True).order_by(Doctor.name).all()
    if request.method == "POST":
        try:
            appt_date = datetime.strptime(request.form["appointment_date"], "%Y-%m-%d").date()
            appt_time = datetime.strptime(request.form["appointment_time"], "%H:%M").time()
            patient_id = int(request.form["patient_id"])
            doctor_id = int(request.form["doctor_id"])
        except (ValueError, KeyError):
            flash("Please provide valid appointment details.", "danger")
            return render_template("appointments/form.html", patients=patients, doctors=doctors)
        conflict = Appointment.query.filter(
            Appointment.doctor_id == doctor_id,
            Appointment.appointment_date == appt_date,
            Appointment.appointment_time == appt_time,
            Appointment.status.in_(ACTIVE_STATUSES),
        ).first()
        if conflict:
            flash("This doctor already has an active appointment at that time.", "danger")
        elif not db.session.get(Patient, patient_id) or not db.session.get(Doctor, doctor_id):
            flash("Select a valid patient and doctor.", "danger")
        else:
            appointment = Appointment(
                patient_id=patient_id, doctor_id=doctor_id,
                appointment_date=appt_date, appointment_time=appt_time,
                reason=request.form.get("reason", "").strip()
            )
            db.session.add(appointment)
            db.session.commit()
            flash("Appointment booked.", "success")
            return redirect(url_for("appointments.index"))
    return render_template("appointments/form.html", patients=patients, doctors=doctors)

@appointments_bp.route("/<int:appointment_id>/status", methods=["POST"])
@login_required
@roles_required("admin", "doctor", "receptionist")
def update_status(appointment_id):
    appointment = db.session.get(Appointment, appointment_id) or abort(404)
    if current_user.role == "doctor":
        doctor = Doctor.query.filter_by(email=current_user.email).first()
        if not doctor or appointment.doctor_id != doctor.id:
            abort(403)
    status = request.form.get("status")
    if status not in ("Pending", "Approved", "Rejected", "Cancelled", "Completed"):
        abort(400)
    if status == "Approved":
        conflict = Appointment.query.filter(
            Appointment.id != appointment.id,
            Appointment.doctor_id == appointment.doctor_id,
            Appointment.appointment_date == appointment.appointment_date,
            Appointment.appointment_time == appointment.appointment_time,
            Appointment.status == "Approved",
        ).first()
        if conflict:
            flash("Another appointment is already approved for this time.", "danger")
            return redirect(url_for("appointments.index"))
    appointment.status = status
    db.session.commit()
    flash("Appointment status updated.", "success")
    return redirect(url_for("appointments.index"))
