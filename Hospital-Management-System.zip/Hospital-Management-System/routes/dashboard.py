from flask import Blueprint, render_template
from flask_login import login_required
from sqlalchemy import func
from models.models import Patient, Doctor, Appointment, Bill, Payment

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/dashboard")
@login_required
def index():
    revenue = db_revenue = Payment.query.with_entities(func.coalesce(func.sum(Payment.amount), 0)).scalar()
    recent_appointments = Appointment.query.order_by(Appointment.id.desc()).limit(6).all()
    recent_patients = Patient.query.order_by(Patient.id.desc()).limit(6).all()
    return render_template(
        "dashboard.html",
        total_patients=Patient.query.count(),
        total_doctors=Doctor.query.count(),
        total_appointments=Appointment.query.count(),
        total_revenue=revenue,
        recent_appointments=recent_appointments,
        recent_patients=recent_patients,
    )
