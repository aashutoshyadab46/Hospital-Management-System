from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required
from models import db
from models.models import Doctor, Department
from routes.common import roles_required

doctors_bp = Blueprint("doctors", __name__, url_prefix="/doctors")

@doctors_bp.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    query = Doctor.query
    if q:
        query = query.filter(Doctor.name.ilike(f"%{q}%") | Doctor.specialization.ilike(f"%{q}%"))
    pagination = query.order_by(Doctor.id.desc()).paginate(page=request.args.get("page", 1, type=int), per_page=10, error_out=False)
    return render_template("doctors/index.html", pagination=pagination, q=q)

@doctors_bp.route("/new", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def create():
    departments = Department.query.order_by(Department.name).all()
    if request.method == "POST":
        doctor = Doctor(
            doctor_code=request.form.get("doctor_code", "").strip(),
            name=request.form.get("name", "").strip(),
            specialization=request.form.get("specialization", "").strip(),
            phone=request.form.get("phone", "").strip(),
            email=request.form.get("email", "").strip() or None,
            department_id=request.form.get("department_id") or None,
            available=request.form.get("available") == "on",
        )
        if not doctor.doctor_code or not doctor.name or not doctor.specialization or not doctor.phone:
            flash("Complete all required fields.", "danger")
        else:
            db.session.add(doctor)
            try:
                db.session.commit()
                flash("Doctor added.", "success")
                return redirect(url_for("doctors.index"))
            except Exception:
                db.session.rollback()
                flash("Could not save doctor. Check unique code/email.", "danger")
    return render_template("doctors/form.html", doctor=None, departments=departments)

@doctors_bp.route("/<int:doctor_id>/edit", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def edit(doctor_id):
    doctor = db.session.get(Doctor, doctor_id) or abort(404)
    departments = Department.query.order_by(Department.name).all()
    if request.method == "POST":
        doctor.name = request.form.get("name", "").strip()
        doctor.specialization = request.form.get("specialization", "").strip()
        doctor.phone = request.form.get("phone", "").strip()
        doctor.email = request.form.get("email", "").strip() or None
        doctor.department_id = request.form.get("department_id") or None
        doctor.available = request.form.get("available") == "on"
        try:
            db.session.commit()
            flash("Doctor updated.", "success")
            return redirect(url_for("doctors.index"))
        except Exception:
            db.session.rollback()
            flash("Could not update doctor.", "danger")
    return render_template("doctors/form.html", doctor=doctor, departments=departments)

@doctors_bp.route("/<int:doctor_id>/delete", methods=["POST"])
@login_required
@roles_required("admin")
def delete(doctor_id):
    doctor = db.session.get(Doctor, doctor_id) or abort(404)
    if doctor:
        from models.models import Appointment
        if Appointment.query.filter_by(doctor_id=doctor.id).first():
            flash("Doctor has appointment history and cannot be deleted.", "warning")
        else:
            db.session.delete(doctor)
            db.session.commit()
            flash("Doctor deleted.", "success")
    return redirect(url_for("doctors.index"))
