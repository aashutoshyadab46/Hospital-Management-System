from decimal import Decimal, InvalidOperation
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required
from models import db
from models.models import Bill, Patient, Payment, Appointment
from routes.common import roles_required

billing_bp = Blueprint("billing", __name__, url_prefix="/billing")

def refresh_status(bill):
    bill.status = "Paid" if bill.balance <= 0 else ("Partially Paid" if bill.amount_paid > 0 else "Unpaid")

@billing_bp.route("/")
@login_required
@roles_required("admin", "receptionist")
def index():
    bills = Bill.query.order_by(Bill.id.desc()).all()
    return render_template("billing/index.html", bills=bills)

@billing_bp.route("/new", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def create():
    patients = Patient.query.order_by(Patient.name).all()
    appointments = Appointment.query.order_by(Appointment.id.desc()).limit(100).all()
    if request.method == "POST":
        try:
            consultation = Decimal(request.form.get("consultation_charge", "0"))
            other = Decimal(request.form.get("other_charges", "0"))
            if consultation < 0 or other < 0:
                raise InvalidOperation
            patient_id = int(request.form["patient_id"])
        except (InvalidOperation, ValueError, KeyError):
            flash("Enter valid non-negative charges and select a patient.", "danger")
            return render_template("billing/form.html", patients=patients, appointments=appointments)
        patient = db.session.get(Patient, patient_id)
        if not patient:
            flash("Select a valid patient.", "danger")
        else:
            bill = Bill(
                bill_number=request.form.get("bill_number", "").strip(),
                patient_id=patient_id,
                appointment_id=request.form.get("appointment_id") or None,
                consultation_charge=consultation,
                other_charges=other,
                total_amount=consultation + other,
            )
            if not bill.bill_number:
                flash("Bill number is required.", "danger")
            else:
                db.session.add(bill)
                try:
                    db.session.commit()
                    flash("Bill generated.", "success")
                    return redirect(url_for("billing.index"))
                except Exception:
                    db.session.rollback()
                    flash("Bill number must be unique.", "danger")
    return render_template("billing/form.html", patients=patients, appointments=appointments)

@billing_bp.route("/<int:bill_id>")
@login_required
@roles_required("admin", "receptionist")
def detail(bill_id):
    bill = db.session.get(Bill, bill_id) or abort(404)
    return render_template("billing/detail.html", bill=bill)

@billing_bp.route("/<int:bill_id>/payment", methods=["POST"])
@login_required
@roles_required("admin", "receptionist")
def payment(bill_id):
    bill = db.session.get(Bill, bill_id) or abort(404)
    try:
        amount = Decimal(request.form.get("amount", "0"))
        if amount <= 0 or amount > bill.balance:
            raise InvalidOperation
    except InvalidOperation:
        flash("Payment must be greater than zero and cannot exceed the balance.", "danger")
        return redirect(url_for("billing.detail", bill_id=bill.id))
    payment = Payment(
        bill_id=bill.id,
        amount=amount,
        payment_method=request.form.get("payment_method", "Cash"),
        transaction_reference=request.form.get("transaction_reference", "").strip()
    )
    db.session.add(payment)
    refresh_status(bill)
    db.session.commit()
    flash("Payment recorded.", "success")
    return redirect(url_for("billing.detail", bill_id=bill.id))
