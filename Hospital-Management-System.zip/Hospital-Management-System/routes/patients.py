from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required
from sqlalchemy import or_
from models import db
from models.models import Patient
from routes.common import roles_required

patients_bp = Blueprint("patients", __name__, url_prefix="/patients")

@patients_bp.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    query = Patient.query
    if q:
        query = query.filter(or_(Patient.name.ilike(f"%{q}%"), Patient.patient_code.ilike(f"%{q}%"), Patient.phone.ilike(f"%{q}%")))
    page = request.args.get("page", 1, type=int)
    pagination = query.order_by(Patient.id.desc()).paginate(page=page, per_page=10, error_out=False)
    return render_template("patients/index.html", pagination=pagination, q=q)

@patients_bp.route("/new", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def create():
    if request.method == "POST":
        try:
            age = int(request.form.get("age", "0"))
            if age < 0 or age > 125:
                raise ValueError
        except ValueError:
            flash("Enter a valid patient age.", "danger")
            return render_template("patients/form.html", patient=None)
        patient = Patient(
            patient_code=request.form.get("patient_code", "").strip(),
            name=request.form.get("name", "").strip(),
            age=age,
            gender=request.form.get("gender", ""),
            phone=request.form.get("phone", "").strip(),
            email=request.form.get("email", "").strip() or None,
            address=request.form.get("address", "").strip(),
            blood_group=request.form.get("blood_group", ""),
            medical_history=request.form.get("medical_history", "").strip(),
        )
        if not patient.patient_code or not patient.name or not patient.phone or not patient.gender:
            flash("Please complete all required fields.", "danger")
            return render_template("patients/form.html", patient=None)
        db.session.add(patient)
        try:
            db.session.commit()
            flash("Patient registered successfully.", "success")
            return redirect(url_for("patients.index"))
        except Exception:
            db.session.rollback()
            flash("Patient code must be unique. Please check the details.", "danger")
    return render_template("patients/form.html", patient=None)

@patients_bp.route("/<int:patient_id>/edit", methods=["GET", "POST"])
@login_required
@roles_required("admin", "receptionist")
def edit(patient_id):
    patient = db.session.get(Patient, patient_id) or abort(404)
    if request.method == "POST":
        patient.name = request.form.get("name", "").strip()
        patient.phone = request.form.get("phone", "").strip()
        patient.email = request.form.get("email", "").strip() or None
        patient.address = request.form.get("address", "").strip()
        patient.medical_history = request.form.get("medical_history", "").strip()
        try:
            patient.age = int(request.form.get("age", patient.age))
            db.session.commit()
            flash("Patient updated.", "success")
            return redirect(url_for("patients.index"))
        except (ValueError, Exception):
            db.session.rollback()
            flash("Could not update patient. Check the entered details.", "danger")
    return render_template("patients/form.html", patient=patient)

@patients_bp.route("/<int:patient_id>")
@login_required
def detail(patient_id):
    patient = db.session.get(Patient, patient_id) or abort(404)
    return render_template("patients/detail.html", patient=patient)

@patients_bp.route("/<int:patient_id>/delete", methods=["POST"])
@login_required
@roles_required("admin")
def delete(patient_id):
    patient = db.session.get(Patient, patient_id) or abort(404)
    from models.models import Appointment, Bill
    has_appointments = Appointment.query.filter_by(patient_id=patient.id).first()
    has_bills = Bill.query.filter_by(patient_id=patient.id).first()
    if has_appointments or has_bills:
        flash("Patient has linked appointment or billing history and cannot be deleted.", "warning")
    else:
        db.session.delete(patient)
        db.session.commit()
        flash("Patient deleted.", "success")
    return redirect(url_for("patients.index"))
