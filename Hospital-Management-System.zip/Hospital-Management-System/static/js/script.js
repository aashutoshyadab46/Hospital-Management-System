document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-confirm]").forEach((element) => {
    element.addEventListener("click", (event) => {
      if (!confirm(element.dataset.confirm || "Are you sure?")) event.preventDefault();
    });
  });
});
